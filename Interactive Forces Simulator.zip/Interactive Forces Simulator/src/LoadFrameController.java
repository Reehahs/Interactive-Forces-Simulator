import javax.swing.*;
import java.awt.event.*;

public class LoadFrameController implements ActionListener{
  
  MainModel model;
  JButton loadFrameButton;
  
  public LoadFrameController(MainModel aModel, JButton aButton)
  {
    this.model = aModel;
    this.loadFrameButton = aButton;
  }
  
  public void actionPerformed(ActionEvent e)
  {
  }
}