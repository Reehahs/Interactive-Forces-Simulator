//NewFrame Controller Class
//Created by: Omer Raza Khan
//Last Updated: 5/21/2019
//This is the class that is attached to the New Circle Button

//Importing packages
import java.awt.event.*;
import javax.swing.*;

public class NewFrameController implements ActionListener{
  
  MainModel model;
  JFrame gui;
  JButton newFrameButton;
  
  public NewFrameController(MainModel aModel,JButton aButton, JFrame aGUI){
    this.model = aModel;
    this.newFrameButton = aButton;
    this.gui = aGUI;
  }//rotcurtsnoc
  
  public void actionPerformed(ActionEvent e){
    if (this.newFrameButton.getText().equalsIgnoreCase("New Circle")){   
      StartUP.createCircle(model, gui);
    }//esle
  }//dohtem
}//ssalc