//Created by Shaheer 
import javax.swing.*;
import java.awt.*;
public class CircleGUI extends JPanel{
  
  private MainModel mainModel;
  private InteractionModel model;
  private CircleComp circle;
  private JLabel label=new JLabel("Circular Motion Simulation"); 
  private Font f1=new Font(Font.SANS_SERIF,Font.BOLD,20);
  
  
  public CircleGUI(InteractionModel aModel,MainModel aMainModel, CircleComp aCircle) {
    this.mainModel=aMainModel;
    this.model=aModel;
    this.circle=aCircle;
    this.model.setCircleGUI(this);
    this.mainModel.setGUI(this);
    this.layoutView();
  }
  
  public void layoutView(){
	  this.setPreferredSize(new Dimension(430,550));
	  this.label.setOpaque(true);
	  this.label.setBackground(Color.BLACK);
	  this.label.setForeground(Color.RED);
	  this.label.setFont(f1);
	  this.add(label);
	  this.setBackground(Color.BLACK);
    this.add(circle);
  }
  
  public CircleComp getCircle(){
     return this.circle;
  }
  
  public void update(){
    
   circle.setRadius(this.model.getRadius());
    
   if(!this.model.getPlace().equals("empty"))
   {
   if((this.model.getPlace().equals("top")) || (this.model.getPlace().equals("bot")))
   {
     this.circle.stop(this.model.getPlace());
   }
   else
   {
     this.circle.stop(this.model.getPlace());
     this.circle.setDirection(true);
   }
   }
   
     
    

    
    
  }
  
}

