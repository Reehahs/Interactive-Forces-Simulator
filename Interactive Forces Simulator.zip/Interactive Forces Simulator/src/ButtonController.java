//Createed By: Shaheer Khan 
//Interaction Model Start/Stop Top/Stop Bottom ButtonController
//Last Modified: 5/21/2019
/*Description: This program is the contoller for the is to communicate with the InterAction Gui and 
               InterAction Panel in order to either start the circle animation or stop it.*/

import javax.swing.*;
import java.awt.event.*;
public class ButtonController implements ActionListener{ //class
  
  private InteractionModel model; //This is the interaction Model Variable 
  private JButton button;  //This is the JButton variable which stores the button which calls the actionListener 
  private JTextField mass;  //This is the textField for mass from the Interaction Panel which includes the user input for the mass of the object
  
  public ButtonController(InteractionModel aModel, JButton button, JTextField massField){ //Constructor 
    super();
    this.button = button;
    this.model=aModel;
    this.mass = massField;
  }//rotcurtsnoc
  
  //Created By: Shaheer Khan
  public void actionPerformed(ActionEvent e) //method          
  {
    boolean buttonPressed = false;
    
    //For when the Start button is pressed 
    if(button.getText().equals("Start Animation")){ 
      this.model.setStart(true);
      this.model.setPlace(" ");
      buttonPressed = true;
    }
    //For when the Stop Bot button is pressed 
    else if (button.getText().equals("Stop (BOTTOM)")){ //if
      this.model.setStart(false);
      this.model.setPlace(button.getText());
      buttonPressed = true;
    }//fi
    //For when the Stop Top button is pressed 
    else if(button.getText().equals("Stop (TOP)")) //if
    {
      this.model.setStart(false);
      this.model.setPlace(button.getText());
      buttonPressed = true;
    }//fi
    
   if (!this.mass.getText().equals(null) || !this.mass.getText().equals("-1")){//if
      this.model.setMass(Double.parseDouble(this.mass.getText()));  
    }//fi
   
   //This happens when any button is pressed in order to take in the input of mass and display the new information
   if(buttonPressed)
     this.calculateForces();
  }//dohtem
  
  //This helper method sets and calculates all the values
  protected void calculateForces(){ //method
    this.model.calculations();
  }//dohtem
}//sslac
    
    