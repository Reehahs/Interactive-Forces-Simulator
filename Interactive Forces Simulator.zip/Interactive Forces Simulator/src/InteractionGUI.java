//Createed By: Shaheer Khan 
//InterAction Gui 
//Last Modified: 5/31/2019
/*Description: This program is the InterAction Gui for the InterAction Panel which interactes with the
               InterAction Gui*/

import javax.swing.*;
import java.awt.*;
public class InteractionGUI extends JPanel{ //class 
    
  private InteractionModel model; //Variable for the InterAction Model 
 
     
  //JComponents
  private JSlider radiusSlider=new JSlider(1,200); //This is a slider component for the radius
  private JSlider velocity=new JSlider(1,100); //This is a slider component for the velocity
  private JButton stopTop=new JButton("Stop (TOP)"); //This is a button component for Stop (TOP)
  private JButton stopBottom=new JButton("Stop (BOTTOM)"); //This is a button component for Stop (BOTTOM)
  private JButton save=new JButton("Save Circle"); //This is a button component which saves the information about a circle onto a file
  private JButton start=new JButton("Start Animation"); //This is a button component for Start Animation
  private JLabel radiusLabel=new JLabel("Radius: "); //This is a label for displaying the radius
  private JLabel velocityLabel=new JLabel("Velocity: "); //This is a label for displaying the velocity
  private JLabel accelerationLabel=new JLabel("Acceleration (m/s�): "); //This is a label for displaying the acceleration
  private JLabel netForceLabel=new JLabel ("Net Force (N): "); //This is a label for displaying the net force
  private JLabel massLabel= new JLabel("Mass(kg) :"); //This is a label for displaying the mass
  private JTextField massField=new JTextField(2); //This is a text field component for the input of the mass
  private JLabel netForceField=new JLabel(); //This is a label for updating the new values of net force
  private JLabel accelerationField=new JLabel(); //This is a label for updating the new values of acceleration
  private Font f1=new Font(Font.SANS_SERIF,Font.PLAIN,15); //This is a font variable used for some of the text
  private JLabel title=new JLabel("Circular Motion Interaction Panel"); //This is a label component for 

  
     
  //JPanels
  private JPanel topButton=new JPanel();
  private JPanel middleMain=new JPanel();
  private JPanel middle=new JPanel();
  private JPanel middleText=new JPanel();
  private JPanel bottomGrid=new JPanel();
  private JPanel topGrid=new JPanel();
     
     
  //Layouts
  private BorderLayout mainLayout=new BorderLayout();
  private GridLayout gridLayoutField= new GridLayout(3,1);
  private GridLayout gridLayoutText=new GridLayout(3,1);
  private GridLayout bottomGridLayout=new GridLayout(2,2);
  private GridLayout topGridLayout=new GridLayout(2,2);
     
     
  public InteractionGUI(InteractionModel aModel) {
   this.model=aModel;
   this.model.setGUI(this);
   this.layoutView();
   this.registerController();
   this.update();
  }
     
  public void layoutView(){
   topButton.setPreferredSize(new Dimension(200,80));
   this.setLayout(mainLayout);
   middle.setLayout(gridLayoutText);
   middleText.setLayout(gridLayoutField);
   bottomGrid.setLayout(bottomGridLayout);
   topGrid.setLayout(topGridLayout);
  
       
   middle.add(massLabel);
   middle.add(netForceLabel);
   middle.add(accelerationLabel);
       
   middleText.add(massField);
   middleText.add(netForceField);
   middleText.add(accelerationField);
  
   this.start.setPreferredSize(new Dimension(150,25));
   this.stopBottom.setPreferredSize(new Dimension(150,25));
   this.stopTop.setPreferredSize(new Dimension(150,25));
   this.save.setPreferredSize(new Dimension(150,25));
   

   topGrid.add(start);
   topGrid.add(stopBottom);
   topGrid.add(save);
   topGrid.add(stopTop);

   topButton.add(title);
   topButton.add(topGrid);
   
   this.velocity.setMajorTickSpacing(5);
   this.velocity.setPaintTicks(false);
   
   this.radiusSlider.setMajorTickSpacing(10);
   this.radiusSlider.setPaintTicks(false);
   
   this.radiusSlider.setBackground(Color.BLACK);
   this.velocity.setBackground(Color.BLACK);
   this.radiusSlider.setForeground(Color.BLACK);
   this.velocity.setForeground(Color.BLACK);
   this.accelerationLabel.setForeground(Color.RED);
   this.massLabel.setForeground(Color.RED);
   this.netForceLabel.setForeground(Color.RED);
   this.stopTop.setBackground(Color.BLACK);
   this.stopTop.setForeground(Color.RED);
   this.stopBottom.setBackground(Color.BLACK);
   this.stopBottom.setForeground(Color.RED);
   this.start.setBackground(Color.BLACK);
   this.start.setForeground(Color.RED);
   this.save.setBackground(Color.BLACK);
   this.save.setForeground(Color.RED);
   this.title.setForeground(Color.WHITE);
   this.title.setFont(new Font(Font.SERIF,Font.CENTER_BASELINE,15));
 
   
   bottomGrid.add(radiusLabel);
   bottomGrid.add(velocityLabel);
   bottomGrid.add(radiusSlider);
   bottomGrid.add(velocity);
       
   this.add(middleMain,BorderLayout.CENTER);
   this.add(bottomGrid,BorderLayout.SOUTH);
   this.add(topButton,BorderLayout.NORTH);
   middleMain.add(middle);
   middleMain.add(middleText);
   this.middle.setBackground(Color.BLACK);
   this.middleText.setBackground(Color.BLACK);
   this.middleMain.setBackground(Color.BLACK);
   this.bottomGrid.setBackground(Color.BLACK);
   this.topButton.setBackground(Color.BLACK);
   this.massField.setText("0");
  }
     
  public void registerController(){
    ButtonController startController=new ButtonController(this.model, start, this.massField);
    ButtonController topController = new ButtonController(this.model, stopTop, this.massField);
    ButtonController bottomController = new ButtonController(this.model, stopBottom, this.massField);
    
    this.stopTop.addActionListener(topController);
    this.stopBottom.addActionListener(bottomController);
    this.start.addActionListener(startController);
     
    SliderController velocityController = new SliderController(this.velocity, this.model, "Velocity");
    SliderController radiusController = new SliderController(this.radiusSlider , this.model, "Radius");
    
    this.velocity.addChangeListener(velocityController);
    this.radiusSlider.addChangeListener(radiusController);
    
    
  }
  
  public void update(){
   velocityLabel.setText("Velocity: "+this.model.getVelocity()+"m/s");
   radiusLabel.setText("Radius: "+this.model.getRadius()+"m");
   netForceField.setText(""+this.model.getNetForce());
   accelerationField.setText(""+this.model.getAcceleration());
   velocityLabel.setForeground(Color.RED);
   radiusLabel.setForeground(Color.RED);
   velocityLabel.setFont(f1);
   radiusLabel.setFont(f1);
   netForceField.setForeground(Color.RED);
   accelerationField.setForeground(Color.RED);
   netForceField.setFont(f1);
   accelerationField.setFont(f1);
   
  }
}


