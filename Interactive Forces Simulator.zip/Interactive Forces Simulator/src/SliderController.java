import javax.swing.*;
import javax.swing.event.*;

public class SliderController implements ChangeListener{
  
  JSlider slider = new JSlider();
  InteractionModel model = new InteractionModel();
  String sliderName;
  
  public SliderController(JSlider newSlider, InteractionModel newModel, String type){
    super();
    this.slider = newSlider;
    this.model = newModel;
    this.sliderName = type;
  }
  
  public void stateChanged(ChangeEvent e)
  {
    if(!this.slider.getValueIsAdjusting())
    {
      this.model.setStart(false);
      
      if(this.sliderName.equals("Radius"))
      {
        this.model.setRadius(this.slider.getValue());
      }
      else if(this.sliderName.equals("Velocity"))
      {
        this.model.setVelocity(this.slider.getValue());
      }
      
      this.model.setStart(true);
      this.model.calculations();
    }
  }
  
}
  