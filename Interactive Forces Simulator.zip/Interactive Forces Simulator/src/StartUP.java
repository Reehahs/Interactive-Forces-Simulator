
//Importing Packages
import javax.swing.*;
import java.awt.*;

public class StartUP{//Main Start-up Class
  
  private static int colorIndex = 0;
  private static final Color [] colorArray = {Color.RED, Color.BLUE,Color.MAGENTA};
  private static final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); //Dimension Object accesses current screen size
  
  public static void main(String[] args){//Main Method
    
    //Instantiating Variables - Dimension Object
    
    //Instantiating Variables - Main Frame
    JFrame mainG = new JFrame(); //JFrame mainG - Main Frame for main window holding load circle and new circle buttons
    
    //Instantiating Variables - Class Objects
    MainModel mainModel = new MainModel();         //MainModel mainModel: Model class connects animation to the display
    MainGUI mainGUI = new MainGUI(mainModel,mainG);           //MainGUI mainGUI: View class displays menu table
    InteractionModel model = new InteractionModel();    //InteractionModel model: Model class calculates forces
    CircleComp circle = new CircleComp(colorArray[colorIndex],model);  //CircleComp circle: Class calculates coordinates for animation   
    InteractionGUI gui = new InteractionGUI(model);     //InteractionGUI gui: View class for interaction panel 
    CircleGUI circleGUI = new CircleGUI(model,mainModel,circle); //CircleGUI circleGUI: View class connecting models
    
    
    
    //Setting Main Frame Properties
    mainG.setContentPane(mainGUI);
    mainG.setSize(250,125);
    mainG.setTitle("Main Window!");
    mainG.setLocation((int)(screenSize.getWidth()*2/4)-250/2,((int)(screenSize.getHeight()/4)+125)); //Location adapts to screen size
    mainG.setDefaultCloseOperation(mainG.EXIT_ON_CLOSE);
    mainG.setVisible(true);
    
    //Class objects added to Main Model to keep track of each circle's appropriate classes
    mainModel.addInteractionGUI(gui);
    mainModel.addInteractionModel(model);
    mainModel.addCircleGUI(circleGUI);
    
    //Creating circle by connecting classes together 
    createCircle(mainModel, mainG);
    mainModel.incrementIndex();//Index keeps track of amount of circles on screen
  }//niam
  
  //createCircle() command method
  //  @param MainModel - The model used as the foundation to identify circle based on classes connected to this model
  //Method instantiates necessary classes for animation and sets properties for frames used to display them
  //Method is public so as to be accessed by the NewFrame Controller, registered with New Circle button
  //Performs action, returns no informatino back to program
  public static void createCircle(MainModel mainModel,JFrame mainG) {
    
    //If statements run if the user has either 0 or 1 circle on screen
    if(mainModel.getIndex()>=0 && mainModel.getIndex()<3) {
    	
    	if(mainModel.getIndex()!=colorIndex) { //This make sure colorIndex doesn't get out of bound
    		colorIndex=mainModel.getIndex();
    	}
 
        if(mainModel.getTotalAmount()==3) {
        	mainG.setVisible(false);
        }
      
      //Instantiating Variables - Class Objects
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();  
      InteractionModel model = new InteractionModel();
      CircleComp circle= new CircleComp(colorArray[colorIndex],model);    
      InteractionGUI gui = new InteractionGUI(model);
      CircleGUI circleGUI=new CircleGUI(model,mainModel,circle);
      
      //Instantiating Variables - Frames
      JFrame mainFrame=new JFrame();
     
      JPanel contentPane=new JPanel();
      
      //Setting Frame Properties - Main Content Panels
      contentPane.add(gui);
      contentPane.add(circleGUI);
      contentPane.setBackground(Color.BLACK);
      mainFrame.setContentPane(contentPane);
      
      //Setting Frame Sizes
      mainFrame.setSize(430,700);

      //Setting Frame titles
      mainFrame.setTitle("Circular Motion Simulator "+(mainModel.getIndex()+1));

      //Setting frames controller
      WindowController frameController=new WindowController(mainFrame,mainG,mainModel);
      mainFrame.addWindowListener(frameController);
      
      //If statements runs if user doesn't have a circle on screen, then frames location adjusted accordingly
      if(mainModel.getIndex()==0) {
    	  mainFrame.setLocation((int)(screenSize.getWidth()/4)-430/2-100,((int)(screenSize.getHeight()/4)-250/2)-75);
      
      }//fi
      //Else, meaning 1 circle is present on screen, then frames location is adjusted accordingly
      else if(mainModel.getIndex()==1){
    	  mainFrame.setLocation((int)(screenSize.getWidth()*3/4)-430/2+100,((int)(screenSize.getHeight()/4)-250/2)-75);
      }//esle
      else if(mainModel.getIndex()==2){
    	  mainFrame.setLocation((int)(screenSize.getWidth()*2/4)-430/2,((int)(screenSize.getHeight()/4)-250/2)-75);
      }

      //Setting Frames visibility
      mainFrame.setVisible(true);
      //Class objects added to Main Model to keep track of each circle's appropriate classes
      mainModel.addInteractionGUI(gui);
      mainModel.addInteractionModel(model);
      mainModel.addCircleGUI(circleGUI);

      //Thread runs independantly to allow animation to continuously run and respond to user inputs
      Thread thread = new Thread(mainModel);
      thread.start();
      colorIndex++;
      mainModel.incrementTotalAmount();
      mainModel.incrementIndex();
    }//fi 
    
  }//dohtem
}//ssalc