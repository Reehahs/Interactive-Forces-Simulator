import javax.swing.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.*;

public class WindowController implements WindowListener {
  private static final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
  JFrame frame;
  MainModel model;
  JFrame eventFrame;
  public WindowController(JFrame AnEventFrame,JFrame aFrame,MainModel aModel)
  {
	  this.eventFrame=AnEventFrame;
	  this.frame=aFrame;
	  this.model=aModel;
  }
  
  public void windowOpened(WindowEvent e) {
	 
  }
  public void windowClosing(WindowEvent e) {
	  if (this.eventFrame.getTitle().equalsIgnoreCase("Circular Motion Simulator "+1)) {
		 
		  this.model.decrementIndex(0);
		  frame.setLocation((int)(screenSize.getWidth()/4)-(250/2)-100,((int)(screenSize.getHeight()/4)+125));
	  }
	  else if(this.eventFrame.getTitle().equalsIgnoreCase("Circular Motion Simulator "+2)) {
		  
		  this.model.decrementIndex(1);
		  frame.setLocation((int)(screenSize.getWidth()*3/4)-(250/2)+100,((int)(screenSize.getHeight()/4)+125));
	  }
	  else if(this.eventFrame.getTitle().equalsIgnoreCase("Circular Motion Simulator "+3)) {
		  this.model.decrementIndex(2);
		  frame.setLocation((int)(screenSize.getWidth()*2/4)-250/2,((int)(screenSize.getHeight()/4)+125));
	  }
	  
	  this.frame.setVisible(true);
	  
	 
  }
  public void windowClosed(WindowEvent e) {

  }
  public void windowIconified(WindowEvent e) {
	  
  }
  public void windowDeiconified(WindowEvent e) {
	  
  }
  public void windowActivated(WindowEvent e) {
	  
  }
  public void windowDeactivated(WindowEvent e) {
	  
	  
  }


}
