import javax.swing.*;
import java.awt.*;

public class MainGUI extends JPanel
{  
  private MainModel model = new MainModel();
  private JButton newFrame = new JButton ("New Circle");
  private JButton loadFrame = new JButton("Load Circle");
  private JLabel title=new JLabel("    Main Menu    ");
  private JFrame frame;
  
  public MainGUI(MainModel aModel,JFrame aFrame)
  {
    super();
    this.model = aModel;
    this.frame = aFrame;
    this.layoutView();
    this.registerControllers();
  }
  
  private void layoutView()
  {
 this.setBackground(Color.BLACK);
 this.newFrame.setBackground(Color.BLACK);
 this.loadFrame.setBackground(Color.BLACK);
 this.newFrame.setForeground(Color.RED);
 this.loadFrame.setForeground(Color.RED);
 this.title.setForeground(Color.WHITE);
 this.title.setFont(new Font(Font.SANS_SERIF,Font.BOLD,20));
 this.add(title);
    this.add(newFrame);
    this.add(loadFrame);
  }
  
  private void registerControllers()
  {
    NewFrameController controller = new NewFrameController(this.model,this.newFrame, this.frame);
    this.newFrame.addActionListener(controller);
  }

    
}