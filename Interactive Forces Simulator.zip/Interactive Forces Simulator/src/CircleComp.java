/* Class Name: Circle Composition
 * Last Modified: 5/30/2019
 * Modified By: Hamzah Shahid
 * Description: The JComponent that contains the entire circle that is manipulated throughout the program. Multiple
 *              circles can be created and displayed simulataneously in different frames. The animation for this 
 *              component is performed in the MainModel*/

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class CircleComp extends JComponent{
  
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//variables
  private double radius = 100.0; //the radius of the circle that is displayed
  private double radiusActual = 100.0; //the actual value of the radius used for calculations
  private double objectRadius = 10.0; //the radius of the object attached to the end of the circle
  
  
  private double velocity; //the velocity of the line
  private boolean direction = true; //left -> false, right -> true
  private boolean directionY; //up -> true, down -> false
  private boolean counterClockwise = false;
  
  private Color color;
  private InteractionModel model;
  private boolean moving = true; //checks if the circle is moving or not
  private boolean top = false; //is the circle at the top? (special case)
  private boolean bottom = false; //is the circle at the bottom? (special case)
  
  private double [][] centerCoordinates = {{200.0,200.0}};
  private double [][] endCoordinates; //the end point of the line (on the circle)
  
  private double lineX = 200.0 - radius; //the xCoordinate of the line
  private double lineY = 200.0; //the yCoordinate of the line
  
  
  //Constructor method for the CircleComposition
  //Created by: Hamzah
  public CircleComp(Color x,InteractionModel aModel) {
    super(); //calls the super method for JComponent
    this.model=aModel;
    this.setPreferredSize(new Dimension(405,405)); //default size of 400px * 400px
    this.color = x;
  }//end method
  
  //sets the direction that the circle is moving in
  //b -> the boolean equivalent value associated with direction 
  //Created by: Hamzah
  public void setDirection(boolean b){
    this.direction = b;
  }//end method
  
  public void setCounterClockwise()
  {
    this.counterClockwise = !this.counterClockwise;
  }
  
  //sets the radius of the CircleComposition to a new value
  //d -> the new radius value
  //Created by: Hamzah
  public void setRadius(double d){
    
    //sets the actual radius and the displayed radius to the same value
    this.radius = d;
    this.radiusActual = d;
    
    //resets the motion of the circle to start from the begining of the path
    this.lineX = 200 - radius;
    this.lineY = 200.0;
    
    //repaints the graphics to match the new instance variables
    repaint();
  }//end method
  
  //paints the CircleComposition into the frame
  //g -> a generic Graphics object
  //Created by: Hamzah
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    
    //cast the Graphics Object as a Graphics 2D Object
    Graphics2D g2 = (Graphics2D) g;
    g2.scale(this.getWidth()/400, this.getHeight()/400); //creates a 400*400 grid where the drawing occurs
    g2.setStroke(new BasicStroke(1.0F/this.getWidth())); //sets the width of the stroke used
       
    //if stop top has been pressed
    if(top){
      
      //sets the end coordinates of the line to the top of the circle
      lineX = centerCoordinates[0][0];
      lineY = centerCoordinates [0][1] - radius;  
    }
    
    //if stop bottom has been pressed
    else if(bottom){
      lineX = centerCoordinates[0][0];
      lineY = centerCoordinates [0][1] + radius;
    }   
    
    //redraws the circle using the instance variable values available
    g2.setColor(Color.WHITE);
    g2.draw(new Line2D.Double(200, 200, lineX, lineY));
    g2.setColor(this.color);
    g2.draw(new Ellipse2D.Double(centerCoordinates[0][0] - radius, centerCoordinates[0][1] - radius, 2*radius, 2*radius));
    
    g2.setColor(Color.GREEN);
    g2.draw(new Ellipse2D.Double(this.lineX - this.objectRadius, this.lineY - this.objectRadius, 
                                 2*this.objectRadius, 2*this.objectRadius));
    
    
    if(bottom)
    {
      g2.setColor(Color.YELLOW);
      g2.draw(new Line2D.Double(200, 200, lineX, lineY));
      g2.draw(new Line2D.Double(200, 200, lineX + radius/4, 200 + radius/4));
      g2.draw(new Line2D.Double(lineX - radius/4, 200 + radius/4, 200, 200));
      g2.drawString("Tension(N): "+this.model.getTension(),140,180);
      g2.setColor(Color.CYAN);
      g2.draw(new Line2D.Double(200,401, lineX, lineY));
      g2.draw(new Line2D.Double(200,401, lineX - radius/4, 401 - radius/4));
      g2.draw(new Line2D.Double(lineX + radius/4, 401 - radius/4, 200, 401));
      g2.drawString("FG(N): "+this.model.getGravity(),75,400);
    }
    
    else if(top)
    {
      g2.setColor(Color.YELLOW);
      g2.draw(new Line2D.Double(200, 200, lineX, lineY));
      g2.draw(new Line2D.Double(200, 200, lineX + radius/4, 200 - radius/4));
      g2.draw(new Line2D.Double(lineX - radius/4, 200 - radius/4, 200, 200));
      g2.drawString("Tension(N): "+this.model.getTension(),140,220);
      g2.setColor(Color.CYAN);
      g2.drawString("FG(N): "+this.model.getGravity(),160,240);
    }
  }//end method
  

  //checks what direction the line is moving in
  //Created by: Hamzah
  public void checkDirection(){
    
    //if the x-coordinate of the line is on the left side of the circle
    if(lineX == (200.0 - radius)){
      this.direction = true; //causes the line to move to right
      this.directionY = true; //causes the line to start moving down
      
    }
    
    //if the x-coordinate of the line is on the right of the circle
    else if(lineX == (200.0 + radius)){
      this.direction = false; //causes the line to move to left
      this.directionY = false; //causes the line to move up
    }//end if
  }//end method
  
  public void checkDirectionCounter(){
    
    if(lineX == (200 - radius))
    {
     this.direction = true; //causes the line to move to left
      this.directionY = false; //causes the line to move up
    }
    else if(lineX == (200 + radius))
    {
      this.direction = true; //causes the line to move to right
      this.directionY = false; //causes the line to start moving down
    }
  }
  
  //returns if the CircleComposition is moving
  //Created by: Hamzah
  public boolean isMoving(){
    return(this.moving);
  }//end method
  
  //determines the new x-value for the line within the circle during the animation
  //Created by: Hamzah
  public void moveX(){
    
    if(!this.counterClockwise)
      this.checkDirection(); //checks what direction the line is currently moving
    else
      this.checkDirectionCounter();
    
    //if its moving to the right
    if(this.direction){
      this.lineX += (1 * (this.radiusActual/100)); //increments the x value of the line based on the circle radius
    }
    
    //if its moving to the left
    else {
      this.lineX -= (1 * (this.radiusActual/100)); //decrements the x value of the line based on the circle radius
    }//end if
    
    this.setY(); //determines the height of the line from the radius based on the x component
    
    //repaints the circle
    repaint();
  }//end method
  
  //Stops the circle
  //x - the String value received from the controller
  //Created by: Hamzah
  public void stop(String x){
    
    //String values are received from the button controller
    
    //if the stop top button is pressed
    if(x.equals("top")){
      top = true; 
      bottom = false;
    }
    
    //if the stop bottom button is pressed
    else if(x.equals("bot")){
      bottom = true;
      top = false;
    }
    
    //if any other button is pressed (i.e: start animation)
    else{
      
      //resets the booleans
      top = false;
      bottom = false;
    }//end if
  repaint();
  }//end method
  
  //sets the height of the line above or below the axis of symmetry
  //Created by: Hamzah
  private void setY(){
    double xDistance = Math.abs(this.lineX - 200.0); //the x-distance between the end of the line and the origin
    
    //if, for any reason, the x-distance is calculated to be greater than the radius, it is reset
    if(xDistance > this.radius){
      
      //checks the direction of the circle
      if(this.direction) //if it is moving to the right
        this.lineX = 200.0 + radius;
      else if (!this.direction) //if it is moving to the left
        this.lineX = 200.0-radius;
      
      //sets the xDistance equal to the value of the radius
      xDistance = this.radius;
      
      //the direction would change as the x value has technically reached the "end" of the circle
      this.directionY = (!this.directionY); //sets the Y-direction to its opposite value
    }//end if
    
    //calculates the height using Pythagorean Theorem
    double height = Math.sqrt((Math.pow(radius, 2) - Math.pow(xDistance, 2)));
    
    //if the height of the circle becomes undefined due to a calculation event
    if(Double.isNaN(height))
      height = 0; //resets the height
    //end if
    
    //checks the direction of the circle to determine where to increment the height
    if(!this.counterClockwise)
      this.checkDirection();
    else
      this.checkDirectionCounter();
    
    //if the line is moving forwards
    if(this.directionY){
      this.lineY = (200.0) + height;
    }
    
    //if the line is moving backwards
    else {
      this.lineY = (200.0) - height;
    }//end if
    
    //calls the repaint method
    repaint();
  }//end method
}//ssalc