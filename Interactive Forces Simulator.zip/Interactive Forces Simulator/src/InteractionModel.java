//Interaction Model
//Created by: Omer Raza Khan
//Last Updated: 5/31/2019
//Model class responsible for the calculations between the user and the circle

public class InteractionModel extends Object{//InteractionModel Class inherits from Object Class
  
  //Declaring Instance Variables
  private InteractionGUI gui;    //The interaction panel GUI
  private CircleGUI circleGui;   //The circle panel GUI 
  
  private double radius = 100.0; //Radius of object                              
  private double velocity = 50;  //Velocity of object
  private double acceleration;   //Acceleration of object
  private double tension;        //Force of tension acting on object
  private double netForce;       //Net force of object
  private double forceGravity;   //Force of gravity acting on the object
  private double massObject;     //Mass of the object
  
  
  private String place = "empty"; //Holds current place of object (top or bottom)
  private Boolean start = true;   //Stores current behaviour of program with respect to Start button
  
  public InteractionModel(){//Constructor of Model class
    super();
  }//rotcurtsnoc
  
  /* ***************  MUTATOR METHODS BELOW  **************** */
  
  /* Name - setGUI(InteractionGUI view) mutator method
   * Parameters - InteractionGUI view: The View class responsible for user interaction
   * Description - Sets the current state of the InteractionGUI View class into a variable accessible by this class 
   * Scope - Accessible by all classes */
  public void setGUI(InteractionGUI view){
    this.gui = view;
  }//dohtem
  
  /* Name - setCircleGUI(CircleGUI circle) mutator method
   * Parameters - CircleGUI circle: The View class responsible for displaying visuals for the circle simulation
   * Description - Sets the current state of the CircleGUI View class into a variable accessible by this class 
   * Scope - Accessible by all classes */
  public void setCircleGUI(CircleGUI circle) {
	this.circleGui = circle;
  }//dohtem
  
  
  /* Name - setStart(boolean decision) mutator method
   * Parameters - boolean decision: The current state of the simulation: True if moving, False if stopped
   * Description - Sets the current state of the motion of the simulator into a variable accessible by this class 
   * Scope - Accessible by all classes */
  public void setStart(boolean decision) {
    this.start = decision;
  }//dohtem

  /* Name - setRadius(double r) mutator method
   * Parameters - double r: The radius of the circle's path
   * Description - Sets the current value of the radius of the circle into a variable accessible by this class 
   * Scope - Accessible by all classes */
  public void setRadius(double r){
    this.radius = r;
    this.updateInteractionGUI();//Updating the user-interaction panel to reflect on radius change
  }//dohtem
  
  /* Name - setVelocity(double v) mutator method
   * Parameters - double v: The velocity of the circle's motion
   * Description - Sets the current value of the velocity of the circle into a variable accessible by this class 
   * Scope - Accessible by all classes */
  public void setVelocity(double v){
    this.velocity = v;
    this.updateInteractionGUI();//Updating the user-interaction panel to reflect on velocity change
  }//dohtem
  
  /* Name - setMass(double m) mutator method
   * Parameters - double m: The mass of the object
   * Description - Sets the current value of the mass of the object into a variable accessible by this class 
   * Scope - Accessible by all classes */
  public void setMass(double m){
    this.massObject = m;
  }//dohtem
 
  /* Name - setPlace(String p) mutator method
   * Parameters - String p: The current state of the position of object. Place is either 'bot' and 'top'
   * Description - Sets the current state of the position of the object into a variable accessible by this class 
   * Scope - Accessible by all classes */
  public void setPlace(String p){
    if (p.equalsIgnoreCase("Stop (BOTTOM)")) {
      this.place="bot";
    }//fi
    else if(p.equalsIgnoreCase("Stop (TOP)")){
      this.place="top";
    }//esle fi
    else
      this.place = " ";
    
    this.calculations();//Calculating all necessary forces
    this.updateInteractionGUI();//Updating the user-interaction panel to reflect on position change
  }//dohtem
  
  /* ***************  ARITHMETIC (NUMERICAL CALCULATION) METHODS BELOW  **************** */ 
  
  /* Name - calculations() method
   * Parameters - None
   * Description - Calculates all necessary forces in order with current velocity and radius of circle
   * Scope - Accessible by only this class */
  public void calculations(){
    this.calculateAcceleration();
    this.calculateGravity();
    this.calculateTension();
    this.calculateNetForce();
  }//dohtem
  
  /* Name - calculateAcceleration() method
   * Parameters - None
   * Description - Calculates acceleration of circle with current velocity and radius of circle
   * Scope - Accessible by only this class */
  private void calculateAcceleration(){
    this.acceleration = Double.parseDouble(String.format("%.2f",Math.pow(this.velocity,2)/this.radius));
    this.updateInteractionGUI();//Updating the user-interaction panel to reflect on calculated acceleration
  }//dohtem
  
  /* Name - calculateGravity() method
   * Parameters - None
   * Description - Calculates force of gravity acting on object given mass and gravitational field constant
   * Scope - Accessible by only this class */
  private void calculateGravity(){
    this.forceGravity = Double.parseDouble(String.format("%.2f",(this.massObject*9.8)));
    this.updateInteractionGUI();//Updating the user-interaction panel to reflect on calculated force
  }//dohtem
  
  /* Name - calculateTension() method
   * Parameters - None
   * Description - Calculates force of tension given mass, current velocity and radius of circle
   * Scope - Accessible by only this class */
  private void calculateTension(){
    if (this.place.equalsIgnoreCase("top") || this.place.equalsIgnoreCase("bot")){
      this.tension = Double.parseDouble(String.format("%.2f",(((Math.pow(this.velocity,2))*this.massObject)/this.radius)));
      this.updateInteractionGUI();//Updating the user-interaction panel to reflect on calculated force
    }//fi
  }//dohtem
  
  /* Name - calculateNetForce() method
   * Parameters - None
   * Description - Calculates net force of object with calculated gravity and tension forces
   * Scope - Accessible by only this class */
  private void calculateNetForce(){
    if (this.place.equalsIgnoreCase("top")){
      this.netForce = Double.parseDouble(String.format("%.2f",this.forceGravity + this.tension));
      this.updateInteractionGUI();//Updating the user-interaction panel to reflect on calculated force
    }//fi
    else if (this.place.equalsIgnoreCase("bot")){
      this.netForce = Double.parseDouble(String.format("%.2f",this.tension - this.forceGravity));
      this.updateInteractionGUI();//Updating the user-interaction panel to reflect on calculated force
    }//esle fi
  }//dohtem
    
  /* ***************  ACCESSOR METHODS BELOW  **************** */
  
  /* Name - getMass() accessor method
   * Description - Returns current mass of object */
  public double getMass(){
    return this.massObject;
  }//dohtem
  
  /* Name - getRadius() accessor method
   * Description - Returns current radius of circle */
  public double getRadius(){
    return this.radius;
  }//dohtem
  
  /* Name - getVelocity() accessor method
   * Description - Returns current velocity of object */
  public double getVelocity(){
    return this.velocity;
  }//dohtem
  
  /* Name - getAcceleration() accessor method
   * Description - Returns current acceleration of object */
  public double getAcceleration(){
    return this.acceleration;
  }//dohtem
  
  /* Name - getTension() accessor method
   * Description - Returns the calculated force of tension acting on object */
  public double getTension(){
    return this.tension;
  }//dohtem
  
  /* Name - getNetForce() accessor method
   * Description - Returns the calculated net force acting on object */
  public double getNetForce(){
    return this.netForce;
  }//dohtem
  
  /* Name - getGravity() accessor method
   * Description - Returns the calculated froce of gravity acting on object */
  public double getGravity(){
    return this.forceGravity;
  }//dohtem
  
  /* Name - getStart() accessor method
   * Description - Returns the current state of simulation */
  public boolean getStart() {
   return start;
  }//dohtem
  
  /* Name - getPlace() accessor method
   * Description - Returns the current position of object undergoing motion */
  public String getPlace() {
   return place;
  }//dohtem
  
  /* ***************  VIEW CLASS UPDATE METHODS BELOW  **************** */
  
  /* Name - updateInteractionGUI() method
   * Description - Method refers to update() method in InteractionGUI class, which updates user-interaction panels
   * Scope - Accessible by all classes */
  public void updateInteractionGUI(){
    this.gui.update();
    this.updateCircleGUI();
  }//dohtem
  
  /* Name - updateCircleGUI() method
   * Description - Method refers to update() method in CircleGUI class, which updates the display of the circle
   * Scope - Accessible by only this class as it's called only from the updateInteractionGUI() method (in this class)*/
  private void updateCircleGUI(){
    this.circleGui.update();
  }//dohtem
}//ssalc