//Main Model
//Created by: Omer Raza Khan
//Last Updated: 5/7/2019
//Model used in main class, view new circles generated in program

//Importing packages
import java.util.*;

public class MainModel extends Object implements Runnable{//Main model class
  
  //Declaring Instance Variables
  CircleGUI gui;
  ArrayList <InteractionGUI> circleInteractionGUIArray  = new ArrayList <InteractionGUI>();
  ArrayList <InteractionModel> circleInteractionModelArray = new ArrayList <InteractionModel>();
  ArrayList <CircleGUI> circleDisplayArray = new ArrayList <CircleGUI>();
  private int index = -1;
  private int totalAmountOfCircles=1;

  public MainModel(){//Constructor instantiates basic object from Object class
    super();
  }//rotcurtsnoc
  
  public void run(){
   move(this.getInteractionModel(index),this.gui.getCircle());
  }
  
  public void move(InteractionModel model, CircleComp circle){
    while(true)
    {
      if(model.getStart())
      {
        circle.moveX();
        
        try
        {
        Thread.currentThread();
		Thread.sleep( (int) (100/(model.getVelocity() * (100/model.getRadius())) ));
        }catch(InterruptedException ie){}
      }
      
      System.out.print(""); //forces system to update
      
    }  
  }
  
  public void setGUI(CircleGUI view){
    this.gui = view;
  }//dohtem
  
  //addInteractionGUI() command method
  //Adds a CircleInteractionGUI object to the array
  //Performs action, returns no information
  public void addInteractionGUI (InteractionGUI cig){
    circleInteractionGUIArray.add(cig);
  }//dohtem
  
  //addInteractionModel() command method
  //Adds a InteractionModel object to the array
  //Performs action, returns no information
  public void addInteractionModel (InteractionModel im){
    circleInteractionModelArray.add(im);
  }//dohtem
  
  //addCircleGUI() command method
  //Adds a CircleGUI object to the array
  //Performs action, returns no information
  public void addCircleGUI (CircleGUI cg){
    circleDisplayArray.add(cg);
  }//dohtem
  
  public InteractionGUI getInteractionGUI(int x){
    return circleInteractionGUIArray.get(x);
  }
  
  public InteractionModel getInteractionModel(int x){
    return circleInteractionModelArray.get(x);
  }
  
  public CircleGUI getCircleGUI(int x){
    return circleDisplayArray.get(x);
  }
  
  public void incrementTotalAmount() {
	  totalAmountOfCircles++;
  }
  public void incrementIndex(){
    index++;
   
  }
  public void decrementIndex(int temp) {
	index=temp;
	totalAmountOfCircles--;
  }
  public int getTotalAmount() {
	  return totalAmountOfCircles;
  }
  
  public int getIndex() {
   return index;
  }
}//ssalc